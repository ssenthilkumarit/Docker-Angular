import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-amount',
  templateUrl: './deposit-amount.component.html',
  styleUrls: ['./deposit-amount.component.scss']
})
export class DepositAmountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
