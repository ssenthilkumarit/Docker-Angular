export class UserDetails {
    username : String = "";
    password : String = "";
    accountNumber : String = "";
    ifscCode : String = "";
}